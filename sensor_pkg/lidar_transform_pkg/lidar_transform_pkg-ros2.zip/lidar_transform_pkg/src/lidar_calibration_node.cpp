#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <cmath>
#include <deque>
#include <numeric>
#include <vector>

class LidarCalibrationNode : public rclcpp::Node
{
public:
    LidarCalibrationNode() : Node("lidar_calibration_node")
    {
        // === 1. 声明参数 (带默认值) ===
        // ROI (Region of Interest) 设置
        this->declare_parameter<double>("roi_min_x", 2.0);  // 避开引擎盖
        this->declare_parameter<double>("roi_max_x", 15.0); // 不看太远
        this->declare_parameter<double>("roi_min_z", -3.0); // 最低高度
        this->declare_parameter<double>("roi_max_z", 0.5);  // 最高高度 (稍微降低一点，避开灌木)
        
        // RANSAC 设置
        this->declare_parameter<double>("ransac_threshold", 0.20); // 距离阈值 20cm

        // 统计平滑设置
        this->declare_parameter<int>("window_size", 50); // 滑动窗口大小

        // 注册参数回调（支持运行时动态修改ROI）
        param_callback_handle_ = this->add_on_set_parameters_callback(
            std::bind(&LidarCalibrationNode::parametersCallback, this, std::placeholders::_1));

        // 更新一下内部变量
        update_params();

        subscription_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            "/rslidar_points", 10, std::bind(&LidarCalibrationNode::topic_callback, this, std::placeholders::_1));
        
        RCLCPP_INFO(this->get_logger(), "=== Lidar Calibration Node Started ===");
        RCLCPP_INFO(this->get_logger(), "Dynamic Params: roi_min_x, roi_max_x, roi_min_z, roi_max_z, ransac_threshold");
    }

private:
    // 参数变量
    double p_min_x_, p_max_x_, p_min_z_, p_max_z_, p_ransac_thresh_;
    int p_window_size_;

    // 滑动窗口
    std::deque<double> pitch_history_;
    std::deque<double> roll_history_;
    std::deque<double> height_history_;

    // 参数回调
    rcl_interfaces::msg::SetParametersResult parametersCallback(
        const std::vector<rclcpp::Parameter> &parameters)
    {
        rcl_interfaces::msg::SetParametersResult result;
        result.successful = true;
        result.reason = "success";
        // 简单处理：只要有参数变动，就更新所有值
        update_params(); 
        // 能够动态清空历史数据可能更好，避免旧参数的干扰
        pitch_history_.clear();
        roll_history_.clear();
        height_history_.clear();
        RCLCPP_INFO(this->get_logger(), "Parameters updated, history cleared.");
        return result;
    }

    void update_params() {
        get_parameter("roi_min_x", p_min_x_);
        get_parameter("roi_max_x", p_max_x_);
        get_parameter("roi_min_z", p_min_z_);
        get_parameter("roi_max_z", p_max_z_);
        get_parameter("ransac_threshold", p_ransac_thresh_);
        get_parameter("window_size", p_window_size_);
    }

    void topic_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
    {
        // 1. 转 PCL
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::fromROSMsg(*msg, *cloud);

        // 2. 降采样 (加速)
        pcl::VoxelGrid<pcl::PointXYZ> sor;
        sor.setInputCloud(cloud);
        sor.setLeafSize(0.15f, 0.15f, 0.15f); // 降采样
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);
        sor.filter(*cloud_filtered);

        // 3. 直通滤波 (使用动态参数)
        pcl::PassThrough<pcl::PointXYZ> pass;
        pass.setInputCloud(cloud_filtered);
        pass.setFilterFieldName("x");
        pass.setFilterLimits(p_min_x_, p_max_x_);
        pass.filter(*cloud_filtered);

        pass.setFilterFieldName("z");
        pass.setFilterLimits(p_min_z_, p_max_z_);
        pass.filter(*cloud_filtered);

        if (cloud_filtered->points.size() < 50) return;

        // 4. RANSAC
        pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
        pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
        pcl::SACSegmentation<pcl::PointXYZ> seg;
        seg.setOptimizeCoefficients(true);
        seg.setModelType(pcl::SACMODEL_PLANE);
        seg.setMethodType(pcl::SAC_RANSAC);
        seg.setDistanceThreshold(p_ransac_thresh_);
        seg.setInputCloud(cloud_filtered);
        seg.segment(*inliers, *coefficients);

        if (inliers->indices.empty()) return;

        float a = coefficients->values[0];
        float b = coefficients->values[1];
        float c = coefficients->values[2];
        float d = coefficients->values[3];

        // 强制法向量向上 (这是物理约束，不是参数)
        if (c < 0) { a = -a; b = -b; c = -c; d = -d; }

        // 过滤非水平面 (比如墙壁)
        if (c < 0.8) return; 

        // 5. 计算瞬时角度 (Rad)
        double cur_pitch_rad = std::atan2(a, c);
        double cur_roll_rad  = std::atan2(-b, c);
        double cur_height    = std::abs(d);

        // 6. 更新滑动窗口
        update_history(pitch_history_, cur_pitch_rad);
        update_history(roll_history_, cur_roll_rad);
        update_history(height_history_, cur_height);

        // 7. 计算平均值
        double avg_pitch_rad = get_average(pitch_history_);
        double avg_roll_rad  = get_average(roll_history_);
        double avg_height    = get_average(height_history_);

        // 8. 打印结果 (双单位显示)
        static int print_count = 0;
        if (++print_count % 5 == 0) { // 降频打印
            print_statistics(avg_pitch_rad, avg_roll_rad, avg_height);
        }
    }

    void print_statistics(double pitch_rad, double roll_rad, double height) {
        // 转换 Rad -> Deg
        double pitch_deg = pitch_rad * 180.0 / M_PI;
        double roll_deg  = roll_rad  * 180.0 / M_PI;

        RCLCPP_INFO(this->get_logger(), 
            "\n========================================\n"
            "STATISTICS (Window: %d frames)\n"
            "----------------------------------------\n"
            "TARGET CORRECTION (Fill these into Transform Node):\n"
            "  Pitch : %8.5f rad  | %8.4f deg\n"
            "  Roll  : %8.5f rad  | %8.4f deg\n"
            "  Height: %8.3f m\n"
            "========================================",
            (int)pitch_history_.size(),
            pitch_rad, pitch_deg,
            roll_rad,  roll_deg,
            height);
    }

    void update_history(std::deque<double>& history, double val) {
        history.push_back(val);
        if (history.size() > (size_t)p_window_size_) {
            history.pop_front();
        }
    }

    double get_average(const std::deque<double>& history) {
        if (history.empty()) return 0.0;
        double sum = std::accumulate(history.begin(), history.end(), 0.0);
        return sum / history.size();
    }

    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscription_;
    OnSetParametersCallbackHandle::SharedPtr param_callback_handle_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LidarCalibrationNode>());
    rclcpp::shutdown();
    return 0;
}