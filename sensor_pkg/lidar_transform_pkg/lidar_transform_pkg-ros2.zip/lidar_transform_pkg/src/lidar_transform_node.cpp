#include <memory>
#include <cmath>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/common/transforms.h>
#include <Eigen/Geometry>

class LidarTransformNode : public rclcpp::Node
{
public:
    LidarTransformNode() : Node("lidar_transform_node")
    {
        // === 1. 参数声明与默认值设置 ===
        // 默认值基于你之前的矩阵: 
        // 平移: x=-2.8, z=-1.2
        // 旋转: 这是一个绕Y轴的旋转。asin(0.1088) ≈ 0.109 rad ≈ 6.24度
        
        this->declare_parameter<double>("x", -0.0);
        this->declare_parameter<double>("y", 0.0);
        this->declare_parameter<double>("z", 0.0);
        this->declare_parameter<double>("roll", 0.02658);
        this->declare_parameter<double>("pitch", 0.05501); // 约等于 6.24度
        this->declare_parameter<double>("yaw", 0.0);

        // 初始化矩阵
        update_transform_matrix();

        // === 2. 注册参数回调 ===
        // 当我们在外部修改参数时，这个回调会被触发，从而更新矩阵
        param_callback_handle_ = this->add_on_set_parameters_callback(
            std::bind(&LidarTransformNode::parametersCallback, this, std::placeholders::_1));

        // === 3. 创建订阅者 ===
        // 订阅原始雷达 Topic
        subscription_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            "/rslidar_points", 
            10, 
            std::bind(&LidarTransformNode::topic_callback, this, std::placeholders::_1));

        // === 4. 创建发布者 ===
        publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>(
            "/rslidar_points_imu", 
            10);
            
        RCLCPP_INFO(this->get_logger(), "Lidar Transform Node Started with Dynamic Params.");
        RCLCPP_INFO(this->get_logger(), "Use 'ros2 param set' or 'rqt' to tune x, y, z, roll, pitch, yaw.");
    }

private:
    // 参数更新回调函数
    rcl_interfaces::msg::SetParametersResult parametersCallback(
        const std::vector<rclcpp::Parameter> &parameters)
    {
        rcl_interfaces::msg::SetParametersResult result;
        result.successful = true;
        result.reason = "success";

        for (const auto &param : parameters)
        {
            if (param.get_name() == "x") transform_x_ = param.as_double();
            else if (param.get_name() == "y") transform_y_ = param.as_double();
            else if (param.get_name() == "z") transform_z_ = param.as_double();
            else if (param.get_name() == "roll") transform_roll_ = param.as_double();
            else if (param.get_name() == "pitch") transform_pitch_ = param.as_double();
            else if (param.get_name() == "yaw") transform_yaw_ = param.as_double();
        }

        update_transform_matrix();
        return result;
    }

    // 根据当前的xyz和rpy重新计算4x4矩阵
    void update_transform_matrix()
    {
        // 1. 获取最新参数值 (首次运行时从param server获取，后续由回调更新变量)
        // 为了安全起见，我们直接从成员变量读取，或者确保成员变量已初始化
        get_parameter("x", transform_x_);
        get_parameter("y", transform_y_);
        get_parameter("z", transform_z_);
        get_parameter("roll", transform_roll_);
        get_parameter("pitch", transform_pitch_);
        get_parameter("yaw", transform_yaw_);

        // 2. 使用 Eigen 构建变换
        // 旋转顺序: 通常为 Z-Y-X (Yaw-Pitch-Roll) 或 RPY
        Eigen::AngleAxisf rollAngle(transform_roll_, Eigen::Vector3f::UnitX());
        Eigen::AngleAxisf pitchAngle(transform_pitch_, Eigen::Vector3f::UnitY());
        Eigen::AngleAxisf yawAngle(transform_yaw_, Eigen::Vector3f::UnitZ());

        Eigen::Quaternionf q = yawAngle * pitchAngle * rollAngle;
        Eigen::Translation3f t(transform_x_, transform_y_, transform_z_);

        transform_matrix_ = (t * q).matrix();

        // 打印日志方便调试
        RCLCPP_INFO(this->get_logger(), "Updated Matrix -> T: [%.2f, %.2f, %.2f], RPY: [%.2f, %.2f, %.2f]",
            transform_x_, transform_y_, transform_z_, transform_roll_, transform_pitch_, transform_yaw_);
    }

    void topic_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg) const
    {
        // === 关键修改：使用 PointXYZI 保留强度信息 (颜色) ===
        pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_in(new pcl::PointCloud<pcl::PointXYZI>);
        
        // 转换 ROS -> PCL
        pcl::fromROSMsg(*msg, *cloud_in);

        // 执行矩阵变换
        pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_out(new pcl::PointCloud<pcl::PointXYZI>);
        pcl::transformPointCloud(*cloud_in, *cloud_out, transform_matrix_);

        // 转换 PCL -> ROS
        sensor_msgs::msg::PointCloud2 output_msg;
        pcl::toROSMsg(*cloud_out, output_msg);

        // 修改 Header
        output_msg.header = msg->header; 
        output_msg.header.frame_id = "rslidar"; // 目标坐标系

        publisher_->publish(output_msg);
    }

    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscription_;
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr publisher_;
    
    // 动态参数回调句柄
    OnSetParametersCallbackHandle::SharedPtr param_callback_handle_;

    // 变换矩阵
    Eigen::Matrix4f transform_matrix_;

    // 缓存当前的参数值
    double transform_x_, transform_y_, transform_z_;
    double transform_roll_, transform_pitch_, transform_yaw_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LidarTransformNode>());
    rclcpp::shutdown();
    return 0;
}